package Config_read;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

//import com.ibm.icu.impl.number.Properties;

public class configyread {



	public static void main(String[] args) throws IOException {
		WebDriver driver;
		Properties prop = new Properties();
		FileInputStream ip = new FileInputStream("C:\\Users\\Shikhar.dubey\\eclipse-workspace\\mishra\\Configuration\\ConfigOpti.properties");
		prop.load(ip);

		System.out.println(prop.getProperty("url"));

			
		
	}

}