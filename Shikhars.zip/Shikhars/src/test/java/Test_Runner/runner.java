package Test_Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "features" }, glue = { "Default" }, plugin = { "pretty",
		"json:target/json-report/cucumber.json", "json:jsonReport" }, dryRun = false, monochrome = true,publish=true
////		strict=true,
//		tags = "@tag1"
//        name = "logo"
//        name="Advanced"

)

public class runner {

}
