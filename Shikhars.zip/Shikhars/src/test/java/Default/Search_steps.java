package Default;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Search_steps {
	public  WebDriver driver;
	


//	@Given("User Opens the Chrome Browser")
//		public void user_opens_the_chrome_browser() {
//		    WebDriverManager.chromedriver().setup();
//		    driver=new ChromeDriver();
//	}
	@Given("I am on Google Search")
	public void i_am_on_google_search() throws IOException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		  WebDriverManager.chromedriver().setup();
		    driver=new ChromeDriver();
	    Properties prop = new Properties();
		FileInputStream ip = new FileInputStream(".\\Configuration\\ConfigOpti.properties");
		prop.load(ip);

		System.out.println(prop.getProperty("url"));
		driver.get(prop.getProperty("url"));
	}
	@When("I add {string} in the Search Box")
	public void i_add_in_the_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//input[@name='q']")).sendKeys("IEngage");
	}
	@When("I click the search button")
	public void i_click_the_search_button() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//div[@class='FPdoLc lJ9FBc']//input[@name='btnK']")).click();
	}
	@When("I clear the Search Box")
	public void i_clear_the_search_box() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//input[@name='q']")).clear();
	}
	@When("I Enter {string} in the Search Box")
	public void i_enter_in_the_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Coforge");
	}
	@When("I click the search button of keyboard")
	public void i_click_the_search_button_of_keyboard() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//button[@aria-label='Google Search']")).click();
	}
	@When("I clear the Search Box Field")
	public void i_clear_the_search_box_field() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//input[@name='q']")).clear();
	    }
	@When("I Search {string} in the Search Box")
	public void i_search_in_the_search_box(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Keyword");
	    
	}
	@When("I click the search button of Google")
	public void i_click_the_search_button_of_google() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//button[@aria-label='Google Search']")).click();
	}
	@Then("I click on the first link")
	public void i_click_on_the_first_link() {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new io.cucumber.java.PendingException();
	    driver.findElement(By.xpath("//h3[contains(text(),'Google Keyword Planner')]")).click();
	}
	@Then("user closes the browser")
	public void user_closes_the_browser() {
	    driver.close();
	}




}
